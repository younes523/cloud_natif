# Microservices refactorisés

Cette archive contient une version réorganisée de l'application avec :

- middleware JWT isolé dans `shared/middlewares/isAuthenticated.js`
- configuration JWT centralisée dans `shared/config/jwtConfig.js`
- génération de token mutualisée dans `shared/utils/generateToken.js`
- correction de l'incohérence `mot_passe` / `password` dans `auth-service`
- protection réactivée sur les routes sensibles de `produit-service` et `commande-service`
- validation métier `verifierPrix` conservée localement dans `produit-service`

## Structure

```text
microservices_archive/
  shared/
    config/
      jwtConfig.js
    middlewares/
      isAuthenticated.js
    utils/
      generateToken.js
  auth-service/
  produit-service/
  commande-service/
```

## Installation

Dans chaque service :

```bash
npm install
```

## Lancement

Dans 3 terminaux séparés :

```bash
cd auth-service && npm run dev
cd produit-service && npm run dev
cd commande-service && npm run dev
```

## Test rapide

1. `POST /auth/register`
2. `POST /auth/login` pour récupérer le token
3. utiliser `Authorization: Bearer <token>` sur :
   - `POST /produit/ajouter`
   - `POST /commande/ajouter`

## Exemple `.env`

Chaque service peut avoir un `.env` similaire :

```env
JWT_SECRET=dev_secret_change_me
JWT_EXPIRES_IN=1h
AUTH_DB_URI=mongodb://127.0.0.1:27017/auth-service
PRODUIT_DB_URI=mongodb://127.0.0.1:27017/produit-service
COMMANDE_DB_URI=mongodb://127.0.0.1:27017/commande-service
PORT=4000
```
